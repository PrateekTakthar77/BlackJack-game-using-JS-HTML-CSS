let card1 = 10
let card2 = 11
let sum = card1 + card2
let hasBlackjack = false
let isAlive = true
let playGround1 = document.getElementById("playround-el")

function startgame() {
let msg = ""
if (sum < 21) {
    msg= "Do you want to draw a new card"
}else if (sum === 21){
    msg= "😎you got blackjack"
    hasBlackjack = true
}else
    msg= "ohh no you are out of the game!"
    console.log(hasBlackjack)
    isAlive = false
    
    playGround1.textContent = msg
}